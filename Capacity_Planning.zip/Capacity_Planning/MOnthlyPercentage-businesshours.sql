select A_DAY, sum(percent_dayOffHours_used) from utilization_on_hours group by 1 order by 1;
