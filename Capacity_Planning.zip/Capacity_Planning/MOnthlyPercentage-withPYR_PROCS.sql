select A_DAY, sum(PERCENT_DAY_USED) from RC_CONCURRENCY_DETAIL 
where QH_USER= 'PYR_PROCS'
group by 1 order by 1;
