select date(qh_tsubmit), rtrim(QH_USER), count(*) query_ct from RC_NZ_QUERY_HISTORY_DEDUPPED  
group by 1,2

order by 1,3 desc;
