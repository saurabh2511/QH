select to_char(year,'9999')||month, rtrim(QH_USER) QH_USER, sum(query_ct) avg_mo_query_ct
from ( select extract( year from qh_tsubmit) year, 
       case extract( month from qh_tsubmit) when  1 then '01'
                                when  2 then '02'
                                when  3 then '03'
                                when  4 then '04'
                                when  5 then '05'
                                when  6 then '06'
                                when  7 then '07'
                                when  8 then '08'
                                when  9 then '09'
                                when  10 then '10'
                                when  11 then '11'
                                when  12 then '12'
       end month,
       rtrim(QH_USER) QH_USER, count(*) query_ct from RC_NZ_QUERY_HISTORY_DEDUPPED group by 1,2,3) x 
group by 1,2

order by 1,3 desc;
