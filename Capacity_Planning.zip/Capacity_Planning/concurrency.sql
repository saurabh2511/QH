select A_TIME, sum(CONCURRENCY_COUNT) concurrency from RC_CONCURRENCY 
where A_day between '2011-11-23' and '2011-11-23'
group by A_TIME
order by 1
;
