export NZ_DATABASE=qh_chargeback
export PATH=.:$PATH
export PATH=/mnt/bin/4.6:$PATH
