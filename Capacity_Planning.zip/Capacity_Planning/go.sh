rc_concurrency.sh QH_CHARGEBACK  NZ_QUERY_HISTORY all
