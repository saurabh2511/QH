#!/bin/bash
#
# Author: Ray Canuel
# Date: Tue Mar 13 10:54:24 EDT 2007
# Version 2.3
#
# (c) 2007 Netezza Corporation.
# This script is provided free of charge by Netezza Corporation as
# a convenience to its customers.  This script is provided "AS-IS"
# with no warranty whatsoever.  The customer accepts all risk in
# connection with the use of this script, and Netezza Corporation
# shall have no liability whatsoever.
#
#

echo -n "$0....."
date
cd //mnt/se/Src/chargeback/
. ~/.bashrc
export PATH=.:/nz/kit/bin:$PATH 
export NZ_PASSWORD=i8tdodb2
export NZ_ADMIN=admin
export NZ_DATABASE=QH_CHARGEBACK


# Persist most recent query history to a real table...
nz_query_history RC_CHARGEBACK NZ_QUERY_HISTORY

# will delete and purge concurrency data for current day
TODAY=`date '+%Y-%m-%d'`
rc_concurrency.sh QH_CHARGEBACK  NZ_QUERY_HISTORY $TODAY

