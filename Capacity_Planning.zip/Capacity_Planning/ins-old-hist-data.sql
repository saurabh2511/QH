-- Inserts relevant data into the old NZ_QUERY_HIST table from Query History Database using a view

insert into NZ_QUERY_HISTORY
select 

PLANSESSIONID, -- QH_SESSIONID
PLANID, -- QH_PLANID
NPSCLIENTID, -- QH_CLIENTID
CLIENTIP, -- QH_CLIIPADDR
SPDBNAME, -- QH_DATABASE
USERNAME, -- QH_USER
QUERYTEXT, -- QH_SQL
LOCALSUBMITTIME, -- QH_TSUBMIT
LOCALSUBMITTIME, -- QH_TSTART
----LOCALSTARTTIME, -- QH_TSTART
LOCALENDTIME, -- QH_TEND
PRIORITY, -- QH_PRIORITY
' ', -- QH_PRITXT
0, --ESTIMATEDCOST, -- QH_ESTCOST
0, -- QH_ESTDISK
0, -- QH_ESTMEM
TOTALSNIPPETS, -- QH_SNIPPETS
DONESNIPPETS, -- QH_SNPTSDONE
RESULTROWS, -- QH_RESROWS
0, -- QH_RESBYTES
0,-- HOST_CPU_SECS
0,-- HOST_DISK_READ_SECS
0,-- HOST_DISK_WRITE_SECS
0,-- HOST_FABRIC_SECS
0,-- SPU_CPU_SECS
0,-- SPU_DISK_READ_SECS
0,-- SPU_DISK_WRITE_SECS
0,-- SPU_FABRIC_SECS
0,-- MAX_SPU_CPU_SECS
0,-- MAX_SPU_DISK_READ_SECS
0,-- MAX_SPU_DISK_WRITE_SECS
0,-- MAX_SPU_FABRIC_SECS
0,-- SQB
0,-- FIT
0,-- PLANNER_ESTIMATE_SECS
0,-- SQB_ESTIMATE_SECS
0,-- SPU_MEM_PEAK
0,-- HOST_MEM_PEAK
0,-- DOWNLOAD_RATE
0,-- WEIGHT
0,-- GK_WAIT_SECS
0,-- GRA_WAIT_SECS
0,-- SN_WAIT_SECS
QUERYELAPSEDTIME, -- EXECUTION_SECS
0 -- IDLE_SECS

from (select distinct * from QHIST..VW_QUERY_HISTORY_PLANQRY )  Dedupe

where QUERYTEXT not like '%SET timezone =%America/New_York%' and
      QUERYTEXT not like '%vacuum%'  and
      QUERYTEXT not like '%transaction%'  and
      QUERYTEXT not like '% _t_%'  and
      QUERYTEXT not like '% _v_%'  and
      QUERYTEXT not like '%version()%'  and
      QUERYTEXT not like 'set %'  and
      QUERYTEXT not like '%current_useroid%'  and
      QUERYTEXT not like '%AUTH system admin%'  and
      QUERYTEXT not like '%commit%'  and
      QUERYTEXT not like '%COMMIT%'  and
 --     QH_DATABASE not in ('SYSTEM')  and
      QUERYTEXT not like '%select current_catalog%'

;
