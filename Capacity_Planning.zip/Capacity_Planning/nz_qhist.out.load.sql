drop table foo2;

drop  table foo2;

create external table foo2 SAMEAS NZ_QUERY_HISTORY
USING (DATAOBJECT('/tmp/nz_qhist.out') CRINSTRING TRUE CTRLCHARS TRUE maxerrors 1000 LOGDIR '/tmp/ray' escapeChar '\' delim '|');

insert into NZ_QUERY_HISTORY select * from foo2;
