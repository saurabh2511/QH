#!/bin/bash
#
# Author: Ray Canuel
# Date: Tue Mar 13 10:54:24 EDT 2007
# Version 2.3
#
# (c) 2007 Netezza Corporation.
# This script is provided free of charge by Netezza Corporation as 
# a convenience to its customers.  This script is provided "AS-IS" 
# with no warranty whatsoever.  The customer accepts all risk in 
# connection with the use of this script, and Netezza Corporation 
# shall have no liability whatsoever.
#

if [ ${#} -ne 3 ]
then
        echo
        echo "Usage $0 dbname tablename {all | day}"
        echo "  This script will calculate rc_concurrency for table."
        echo "  Parameters: "
        echo "   dbname:    where persisted query history is stored"
        echo "   Tablename: where query history is persisted."
        echo "   all | DAY: yyyy-mm-dd : 2007-01-01  OR all"
        echo "        all: truncate then calc concurrency all query history to today....."
        echo "        DAY: delete >=DAY then calc concurrency from the parameterized day to today....."
        echo
        exit
fi
echo

export NZ_DATABASE=$1
export QHIST_TABLE=`echo $2 | tr "[A-Z]" "[a-z]"`
export QHIST_TABLE_DEDUPPED="rc_${QHIST_TABLE}_dedupped"
export OPTION=$3


echo  "Checking for persisting $QHIST_TABLE to disk......"
if [ $QHIST_TABLE = "_v_qryhist" ]
then
	echo ""
	echo "FATAL ERROR: you should be persisting $QHIST_TABLE to disk....."
	echo "   Check with Netezza Tech Support for support utility to persist _v_qryhist to disk"
	echo "    - nz_query_history utility to persist _v_qryhist to disk"
	echo "   "
	echo "Exiting..."
	echo
        exit
else
	echo "  Success. "
        echo "  You are persisting _v_qryhist to the $QHIST_TABLE table."
	echo
fi



echo  -n "Checking for dupps in $QHIST_TABLE to make sure itis not loaded twice......"
QHISTDUPS=`nzsql -A -t -c " select count(*) from ( select QH_SESSIONID , QH_PLANID    , QH_TSUBMIT  , QH_DATABASE, qh_user, count(*) from $QHIST_TABLE group by QH_SESSIONID , QH_PLANID    , QH_TSUBMIT, QH_DATABASE, qh_user having count(*) > 1) as dedupp;"`
if [ $QHISTDUPS -ne 0 ]; then
	echo 
        echo " FAILED."
        echo "  There are $QHISTDUPS duplicate record in ${QHIST_TABLE}."
	echo "  Exiting..."
	echo
        exit
else
	echo 
	echo "  Success.... No Dups."
fi
echo 

#
# Purge concurrency info before re-calculating
#
if [ $OPTION = "all" ]
then
    echo "Truncating working version of $QHIST_TABLE ...."
    nzsql <<EOF
        \echo -n '  Truncating data from rc_concurrency ....'
	truncate table rc_concurrency ;

        \echo -n '  Truncating data from rc_concurrency_detail ....'
	truncate table rc_concurrency_detail ;
EOF
    MIN_DATE=`nzsql -A -t -c "select min(qh_tstart::date) from $QHIST_TABLE"`

    NO_DAYS_FROM_TODAY=`nzsql -A -t -c "select current_date - '${MIN_DATE}'::date"`
else
    MIN_DATE=`nzsql -A -t -c "select ('$OPTION'::date);"`
    echo "Deleting ${MIN_DATE} worth of data ...."
    nzsql <<EOF

        \echo -n '  Purging ${MIN_DATE} data from rc_concurrency ....'
	delete from rc_concurrency where A_DAY = '${MIN_DATE}' ;

        \echo -n '  Purging ${MIN_DATE} data from rc_concurrency_detail ....'
	delete from rc_concurrency_detail where A_DAY = '${MIN_DATE}' ;
EOF

   NO_DAYS_FROM_TODAY=1
fi
echo


echo "Making working copy of ${QHIST_TABLE} data ...."
nzsql <<EOF
        \echo -n '  Truncating data from $QHIST_TABLE_DEDUPPED ....'
    truncate table $QHIST_TABLE_DEDUPPED;

        \echo -n '  Transformding data into $QHIST_TABLE_DEDUPPED ....'
    insert into $QHIST_TABLE_DEDUPPED 
    select distinct edw_query_history.*,
        ( extract ( days    from ( qh_tend - qh_tstart ) ) * 86400 ) +
        ( extract ( hours   from ( qh_tend - qh_tstart ) ) *  3600 ) +
        ( extract ( minutes from ( qh_tend - qh_tstart ) ) *    60 ) +
        ( extract ( seconds from ( qh_tend - qh_tstart ) )         )
        + 1
    as elapsed_seconds
    , qh_tstart::date as qh_tstart_dt
    , qh_tend::date as qh_tend_dt
    from ${QHIST_TABLE} edw_query_history
EOF


echo
echo "Query History logged since: $MIN_DATE"
echo "              # days since: $NO_DAYS_FROM_TODAY"
echo

# This table calculates the rc_concurrency within a day and 
# breaks down the % of secs to be charged back if a query 
# is running during this time.  
#
DAY=0
while [ ${DAY} -le ${NO_DAYS_FROM_TODAY} ]
do
   THIS_DAY=`nzsql -A -t -c "select $DAY + '${MIN_DATE}'::date"`
   echo -n "Adding data for ${THIS_DAY} into rc_concurrency...."

   nzsql <<EOF
   insert into rc_concurrency
-- Aggregate individual seconds and calculate rc_concurrency
select
   a_day,
   a_time,
   SECS_FROM_MIDNIGHT,
   count(*) as concurrency_count,
   ( (1::numeric(8,6)/count(*)) ) seconds_running
from 
( 
   -- Find seconds that start and end in the same day

   select  qh_tstart_dt as a_day, a_time,SECS_FROM_MIDNIGHT 
   from $QHIST_TABLE_DEDUPPED QHIST, rc_days_time 
   where
     QHIST.qh_tstart_dt = '${THIS_DAY}'::date and
     QHIST.qh_tstart between '${THIS_DAY} 00:00:00' and '${THIS_DAY} 23:59:59' and
     QHIST.qh_tstart_dt = QHIST.qh_tend_dt and
     a_time between qh_tstart::time and qh_tend::time

UNION ALL

   -- Find seconds BEFORE midinight where start/end straddle midnight;  
   select  qh_tstart_dt as a_day, a_time,SECS_FROM_MIDNIGHT 
   from $QHIST_TABLE_DEDUPPED QHIST, rc_days_time 
   where
     QHIST.qh_tstart_dt = '${THIS_DAY}'::date and
     QHIST.qh_tstart between '${THIS_DAY} 00:00:00' and '${THIS_DAY} 23:59:59' and
     QHIST.qh_tstart_dt = (QHIST.qh_tend_dt-1) and
     a_time between qh_tstart::time  and  '23:59:59'

UNION ALL

   -- Find seconds AFTER midinight where start/end straddle midnight;  
   select  qh_tEND_dt as a_day, a_time,SECS_FROM_MIDNIGHT 
   from $QHIST_TABLE_DEDUPPED QHIST, rc_days_time 
   where
     -- ends AFTER midnight
     QHIST.qh_tEND_DT = '${THIS_DAY}'::date and 
     QHIST.qh_tEND between '${THIS_DAY} 00:00:00' and '${THIS_DAY} 23:59:59' and

     -- starts BEFORE midnight Note it can start many days before
     --QHIST.qh_tstart_dt = (QHIST.qh_tend_dt-1) and 
     QHIST.qh_tstart_dt != (QHIST.qh_tend_dt) and 
     a_time between '00:00:00' and qh_tend::time 
) as days_seconds
group by 1,2,3 

EOF

   echo -n "Adding data for ${THIS_DAY} into rc_concurrency_detail...."
   nzsql <<EOF
   insert into rc_concurrency_detail
   select
     a_day,
     QH_DATABASE,
     QH_USER,
        count( distinct qh_tstart) as no_queries,
        min( ELAPSED_SECONDS) as min_query_time,
        max( ELAPSED_SECONDS) as max_query_time,
       avg( ELAPSED_SECONDS) as avg_query_time,
       sum(seconds_running)::numeric(8,2) as total_secs_running,
       (select count(*) from rc_DAYS_TIME) as no_secs_in_a_day,
  
       (
          sum(seconds_running)::numeric(8,2) 
       /
         (select count(*) from rc_DAYS_TIME)  -- number of secs in a day
       ) * 100
  
       as percent_day_used
  from
  (
  select   
    a_day, QH_DATABASE,QH_USER, qh_tstart, ELAPSED_SECONDS, seconds_running
  from 
     $QHIST_TABLE_DEDUPPED QHIST,
     rc_concurrency
     where
       a_time between qh_tstart::time and qh_tend::time and
       QHIST.qh_tstart_dt = '${THIS_DAY}' and
       a_day = '${THIS_DAY}' and
       QHIST.qh_tstart between '${THIS_DAY} 00:00:00' and '${THIS_DAY} 23:59:59' and
       QHIST.qh_tstart_dt = QHIST.qh_tend_dt 
       and a_day = QHIST.qh_tstart_dt
  
  UNION ALL
  
     -- Find seconds BEFORE midinight where start/end straddle midnight;
     select  
         a_day, QH_DATABASE, QH_USER,qh_tstart, ELAPSED_SECONDS, seconds_running
     from $QHIST_TABLE_DEDUPPED QHIST, rc_concurrency
     where
       QHIST.qh_tstart_dt = '${THIS_DAY}' and
       QHIST.qh_tstart between '${THIS_DAY} 00:00:00' and '${THIS_DAY} 23:59:59' and
       QHIST.qh_tstart_dt = (QHIST.qh_tend_dt-1) and
       a_time between qh_tstart::time  and  '23:59:59'
       and a_day = QHIST.qh_tstart_dt
  
  UNION ALL
  
     -- Find seconds AFTER midinight where start/end straddle midnight;
     select  
         a_day, QH_DATABASE, QH_USER, qh_tstart, ELAPSED_SECONDS, seconds_running
     from $QHIST_TABLE_DEDUPPED QHIST, rc_concurrency
     where
       -- ends AFTER midnight
       a_day = '${THIS_DAY}' and
       QHIST.qh_tend_dt = '${THIS_DAY}' and
       QHIST.qh_tend between '${THIS_DAY} 00:00:00' and '${THIS_DAY} 23:59:59' and
  
       -- starts BEFORE midnight
       QHIST.qh_tstart::date != QHIST.qh_tend::date AND
       a_time between '00:00:00' and qh_tend::time
       and a_day = QHIST.qh_tend_dt
  
  ) as queries_running_in_a_day
  
  group by 1,2,3
;
EOF

   echo
   DAY=`expr ${DAY} + 1`

done

