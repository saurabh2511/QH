/*

Get utilization on hours from 8:00 am--->18:00 pM Monday -->Friday.
	to_char(date,'D')              as day_of_week -- 2(mon)-->6(friday); 
	to_char(date,'D')::byteint in (2,3,4,5,6)

# (c) 2007 Netezza Corporation.
# This SQL script is provided free of charge by Netezza Corporation as
# a convenience to its customers.  This script is provided "AS-IS"
# with no warranty whatsoever.  The customer accepts all risk in
# connection with the use of this script, and Netezza Corporation
# shall have no liability whatsoever.


*/


create or replace view utilization_on_hours as 
   select
     a_day,
--      QH_DATABASE,
     QH_USER,
        count( distinct qh_tstart) as no_queries,
--        min( ELAPSED_SECONDS) as min_query_time,
--        max( ELAPSED_SECONDS) as max_query_time,
--       avg( ELAPSED_SECONDS) as avg_query_time,
       sum(seconds_running)::numeric(8,2) as total_secs_running,
       (select count(*) from rc_DAYS_TIME where A_TIME between '08:00:00' and '18:00:00') as no_secs_onhours,
  
       (
          sum(seconds_running)::numeric(8,2) 
       /
         -- (select count(*) from rc_DAYS_TIME)  -- number of secs in a day
         (select count(*) from rc_DAYS_TIME where A_TIME between '08:00:00' and '18:00:00')  -- number of secs in a day onHours
       ) * 100
  
       as percent_dayOffHours_used
  from
  (
  select   
    a_day, QH_DATABASE,QH_USER, qh_tstart, ELAPSED_SECONDS, seconds_running
  from 
     RC_NZ_QUERY_HISTORY_DEDUPPED QHIST,
     rc_concurrency
     where
       a_time between '08:00:00' and '18:00:00' AND
       a_time between qh_tstart::time and qh_tend::time AND
          QHIST.qh_tstart between '2010-01-01 00:00:00' and '2011-12-31 18:00:00' and
       QHIST.qh_tstart_dt = QHIST.qh_tend_dt 
       and a_day = QHIST.qh_tstart_dt
  
       AND rc_concurrency.A_TIME between '08:00:00' and '18:00:000'
       -- MOnday-->Friday Only
       AND to_char(a_day,'D')::byteint in (2,3,4,5,6)

  ) as queries_running_in_a_day

  group by 1, 2
-- order by 1 asc
;

