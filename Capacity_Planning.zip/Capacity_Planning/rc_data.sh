#!/bin/bash
#
# Author: Ray Canuel
# Date: Tue Mar 13 10:54:24 EDT 2007
# Version 2.3
#
# (c) 2007 Netezza Corporation.
# This script is provided free of charge by Netezza Corporation as 
# a convenience to its customers.  This script is provided "AS-IS" 
# with no warranty whatsoever.  The customer accepts all risk in 
# connection with the use of this script, and Netezza Corporation 
# shall have no liability whatsoever.
#

if [ ${#} -ne 1 ]
then
        echo "Usage $0 dbname "
        echo "  This script will create all necessary tables for the rc"
        echo
        exit
fi


export NZ_DATABASE=$1

nzsql -a <<EOF
    truncate table rc_concurrency_detail ;
    truncate table rc_days_time;
    truncate table rc_concurrency;
    truncate table rc_dbsize_history;
EOF

echo "Loading RC_DAYS_TIME....."
cp ./rc_days_time.sql.sh /tmp/rc_days_time.sql.sh2
chmod 666 /tmp/rc_days_time.sql.sh2

nzload -u ${NZ_USER} \
                -pw ${NZ_PASSWORD} \
                -db ${NZ_DATABASE} \
                -t RC_DAYS_TIME \
                -nullValue '' \
                -ignoreZero yes \
                -ctrlChars \
                -delim "|" \
                -timeStyle 24HOUR \
                -timeDelim ':' \
                -dateStyle YMD \
                -dateDelim - \
                -bf /tmp/rc_days_time.bf2 \
                -df /tmp/rc_days_time.sql.sh2 \
                -maxErrors   1 \
                -lf /tmp/rc_days_time.nzlog2
