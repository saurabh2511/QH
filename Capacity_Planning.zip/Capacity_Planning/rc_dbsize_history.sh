#!/bin/bash
#
# Author: Ray Canuel
# Date: Tue Mar 13 10:54:24 EDT 2007
# Version 2.3
#
# (c) 2007 Netezza Corporation.
# This script is provided free of charge by Netezza Corporation as
# a convenience to its customers.  This script is provided "AS-IS"
# with no warranty whatsoever.  The customer accepts all risk in
# connection with the use of this script, and Netezza Corporation
# shall have no liability whatsoever.
#
#
if [ ${#} -ne 1 ]
then
        echo "Usage $0 dbname "
        echo "  This script will capture the dbsize for today and store it"
        echo "  in the rc_chargeback {dbname..rc_dbsize_history} database. "
        echo
        exit
fi


#nzstats listFields -type table
#DB Name      Table Name                                 Disk Space Space Skew
#------------ ------------------------------------------ ---------- ----------
#INTERAC      STAGING_TRANSACTION                              0 KB       0.00

# Use nzstats to get the DB Name, Table Name, Disk Space, and Space Skew
# Then use awk/grep to make it a loadable ascii delimited file.
# Then add TODAY's date to the end of each record.
#
TODAYS_DATE=`date '+%Y-%m-%d'`
date
echo -n "Running nzstats -type table to get database sizing information....."
echo $TODAYS_DATE
echo 
nzstats -type table -cols 2,4,9,15  | \
#cat /tmp/dbsize.out | \
	grep -v "OLE DB" | \
	awk {' print $1 "|" $2 "|" $3 "|" $5 '} | \
	tr "[A-Z]" "[a-z]" | \
	egrep -v "\-\-" | \
	grep -v "|||" | \
	grep -v "db|name|" > /tmp/nzsize.ld

chmod 666 /tmp/nzsize.ld

nzsql $DBNAME<<EOF

insert into rc_dbsize_history 
     select 
       rc_dbsize_history_ext.db_name,
       rc_dbsize_history_ext.table_name,
       ((rc_dbsize_history_ext.disk_space_gb/1024)/1024)::numeric(16,2),
       rc_dbsize_history_ext.space_skew,
       current_timestamp
     from  rc_dbsize_history_ext;

EOF
#rm /tmp/nzsize.ld
