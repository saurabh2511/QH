
create table temp_foo as
	select * from RC_DBSIZE_HISTORY;

select count( distinct A_DAY )from RC_CONCURRENCY;
select count( * )from RC_DBSIZE_HISTORY;

truncate table RC_DBSIZE_HISTORY;

insert into RC_DBSIZE_HISTORY
select
 DB_NAME       ,
 TABLE_NAME    ,
 DISK_SPACE_GB ,
 SPACE_SKEW    ,
 A_DAY::timestamp
from temp_foo, (select distinct A_DAY from RC_CONCURRENCY) as trend_hist
;
