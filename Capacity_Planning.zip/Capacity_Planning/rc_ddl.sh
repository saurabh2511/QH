#!/bin/bash
#
# Author: Ray Canuel
# Date: Tue Mar 13 10:54:24 EDT 2007
# Version 2.3
#
# (c) 2007 Netezza Corporation.
# This script is provided free of charge by Netezza Corporation as 
# a convenience to its customers.  This script is provided "AS-IS" 
# with no warranty whatsoever.  The customer accepts all risk in 
# connection with the use of this script, and Netezza Corporation 
# shall have no liability whatsoever.
#

if [ ${#} -ne 2 ]
then
        echo "Usage $0 dbname tablename"
        echo "  This script will create all necessary tables for the rc"
        echo "  Database where query history is stored "
        echo "  Table name where query history is persisted."
        echo
        exit
fi

export NZ_DATABASE=$1
export QHIST_TABLE=`echo $2 | tr "[A-Z]" "[a-z]"`
export QHIST_TABLE_DEDUPPED="rc_${QHIST_TABLE}_dedupped"


NPSSIZE_GBS=`nzsql system -A -t <<eof
        SELECT  
           TO_CHAR ( SUM ( spp_size ) / ( 1073741824 ) , '999990') AS "TB"
           -- TO_CHAR ( SUM ( spp_size ) / ( 1099511627776 ) , '990.000') AS "TB"
        FROM    _v_spupart, _t_dslice
        WHERE   spp_hwid = ds_pridskid and spp_ptid = ds_priptid;
eof
`
NPSSIZE_GBS=128000
echo -n "Defaulting NPS size to ...."
echo 	"$NPSSIZE_GBS gigabytes."


nzsql -a <<EOF
    create table $QHIST_TABLE_DEDUPPED as
    select edw_query_history.*, 
           0::integer as ELAPSED_SECONDS,
           '2005-01-06'::date as QH_TSTART_DT,
           '2003-10-13'::date as QH_TEND_DT
    from ${QHIST_TABLE} edw_query_history
    limit 0
    distribute on random;

    create table rc_concurrency_detail 
    (
 	A_DAY              DATE                   not null ,
 	QH_DATABASE        CHARACTER VARYING(255) ,
 	QH_USER            CHARACTER VARYING(255) ,
 	TOTAL_QUERIES      BIGINT                 not null ,
 	MIN_QUERY_TIME     INTEGER                not null ,
 	MAX_QUERY_TIME     INTEGER                not null ,
 	AVG_QUERY_TIME     NUMERIC(38,6)          not null ,
 	TOTAL_SECS_RUNNING NUMERIC(8,2)           not null ,
 	NO_SECS_IN_A_DAY   BIGINT                 not null ,
 	PERCENT_DAY_USED   NUMERIC(31,21)         not null 
    ) distribute on random;

    create table rc_days_time
    (
     a_time time not null,
     secs_from_midnight integer not null
    )
    distribute on (A_TIME);

    create table rc_concurrency
    (
     A_DAY              DATE           NOT NULL,
     A_TIME             TIME           NOT NULL,
     SECS_FROM_MIDNIGHT INTEGER        NOT NULL,
     CONCURRENCY_COUNT  byteint        NOT NULL,
     SECONDS_RUNNING    NUMERIC(8,7) NOT NULL
    ) distribute on (A_TIME);

    create table rc_dbsize_history
    (
    db_name         char(128)      not null,
    table_name      char(128)      not null,
    disk_space_gb   numeric(16,2)  not null,-- its in kb from nzstats
    space_skew      numeric(16,10) not null,
    disk_space_dt   timestamp
    ) distribute on random;

    create external table rc_dbsize_history_ext
        sameas rc_dbsize_history
        using ( DATAOBJECT ('/tmp/nzsize.ld') FILLRECORD TRUE DELIMITER '|' FILLRECORD  ON );
EOF


nzsql <<EOF
-- Combine 1) Disk space and 2) Utilization by database and date
-- full outer because we may have one and not the other
-- 
--  A_DAY    |     A_DATABASE     | TOTAL_SIZE |       PERCENT_USED
------------+--------------------+------------+--------------------------
-- 2007-02-15 | nzedwprd_tgt       |     863.91 | 17.460509259259259259200
-- 2007-02-15 | nzmrdwprd_stg      |     336.67 |  5.385590277777777777800
-- 2007-02-15 | nzctiprd_arch      |      85.35 |  0.002314814814814814800
-- 2007-02-15 | nzedwprd_tgt_proxy |       2.51 |  0.920868055555555555600
-- 2007-02-15 | nzmrwprd_stg       |       0.83 |  0.501157407407407407400
-- 2007-02-15 | nz_smart_collect   |       0.00 |  0.001157407407407407400
-- 2007-02-15 | system             |       0.00 |  4.032789351851851851900
--
--
create or replace view rc_v_chargeback_summary as
select  
  case when dbsize.a_day is null 
       then utilization.a_day 
       else dbsize.a_day 
  end as a_day, 
  case when dbsize.a_database is null 
       then utilization.a_database 
       else dbsize.a_database 
  end as a_database, 
  dbsize.total_size as total_size_GB, 
  -- DBsize% is based on 80% of entire user space 8150z $NPSSIZE_GBS
  (dbsize.total_size/($NPSSIZE_GBS * 0.80))*100 as percent_db_used, 
  utilization.percent_used 
from 
     (
     select 
           A_DAY,
           rtrim(QH_DATABASE) as a_database, 
           sum(PERCENT_DAY_USED) as percent_used
     from RC_CONCURRENCY_DETAIL
     group by 1,2
     ) as utilization
FULL OUTER JOIN 
    (
	select 
            DISK_SPACE_DT::date as a_day, 
            rtrim(dbsize.DB_NAME) as a_database, 
            sum(DISK_SPACE_GB) as total_size
	from RC_DBSIZE_HISTORY dbsize
	group by 1,2
     ) as dbsize

ON
(
  dbsize.a_day = utilization.a_day and
  dbsize.a_database = utilization.a_database 
)
;

-- select * from rc_v_chargeback_summary where a_day = '2007-02-15'


EOF
