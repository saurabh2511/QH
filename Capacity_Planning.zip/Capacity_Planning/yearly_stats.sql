create or replace view yearly_stats as select RECORD_DT, DB_NAME, round((sum(SIZE_KB)/1024)/1024) from NZ_TABLE_STATS group by 1,2;

